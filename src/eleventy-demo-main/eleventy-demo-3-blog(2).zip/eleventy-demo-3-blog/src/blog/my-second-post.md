---
layout: layout.njk
title: I have more thoughts here
tags: blog
---

# My second post

These are more profound thoughts.
