---
layout: layout.njk
title: Welcome to my blog
tags: blog
---

# Welcome

These are profound thoughts.
